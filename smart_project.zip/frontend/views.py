from django.shortcuts import render

# Create your views here.


def home(request):
    return render(request, 'front/index.html')


def aboutUs(request):
    return render(request, 'front/pages/about-us.html')


def contactUs(request):
    return render(request, 'front/pages/contact-us.html')


def shop(request):
    return render(request, 'front/shop/shop.html')

def vendor_list(request):
    return render(request, 'front/vendor/vendor-store-list.html')

def single_vendor(request):
    return render(request, 'front/vendor/vendor-store-single.html')

def become_a_vendor(request):
    return render(request, 'front/vendor/become-a-vendor.html')

def blog_list(request):
    return render(request, 'front/blog/blog-list.html')

def post_single(request):
    return render(request, 'front/blog/blog-single.html')



def error404(request):
    return render(request, 'front/pages/error-404.html')

def faq(request):
    return render(request, 'front/pages/faq.html')

def myAccount(request):
    return render(request, 'front/profile/my-account.html')

def wishlist(request):
    return render(request, 'front/shop/wishlist.html')

def compare(request):
    return render(request, 'front/shop/compare.html')

def add_To_cart(request):
    return render(request, 'front/order/Addcart.html')

def checkOut(request):
    return render(request, 'front/order/checkout.html')

def orderComplete(request):
    return render(request, 'front/order/orderComplete.html')